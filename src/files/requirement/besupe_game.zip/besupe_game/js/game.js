var game = {

	original : [],

	initNum : null,

	initNum2 : null,

	index : null,

	timeMinute : null,

	timeSecond : null,

	wxImg : '',//微信分享

	wxName : '宝宝',

	addTime : null,

	minResult : 0,

	secResult : 0,
	
	startTime: null,
	
	endTime:null,

	//初始化图片的位置
	init:function(){
		//TODO 获取服务器生成的图片顺序
		
		var count=8;
		game.original=new Array();//原始数组
		//给原始数组original赋值
		for (var i=0;i<count;i++){
			 game.original[i]=i+1;
		}
		game.original = game.original.concat(game.original);
		game.original.sort(function(){
			return 0.5 - Math.random(); 
		});
		for(var j=1;j<17;j++){
			$(".game-block a:nth-child("+j+")").addClass('on'+game.original[j-1]);
		}
	},

	//点击事件
	clickEvent:function(){
		var clickTimes = 0;
				
		$("#G_net").on("click",function(e){
			var $this = $(this);
			var width = $this.width() / 4;
			var height = $this.height() / 4;
			var x = Math.floor(e.offsetX / width);
			var y = Math.floor(e.offsetY / height);
			var index = y * 4 + x;
			$(".game-block a").eq(index).trigger("click");
		});
		
		$(".game-block a").click(function(event) {
			if(!$(this).hasClass('show')){
				var className = $(this).attr('class');
				$(this).addClass('show');
				$(".game-block").addClass(className);
			}else{
				return false;
			}
			
			//TODO 每一次点击，发送点击的坐标(这里realIndex是顺序坐标,也可以传X,Y坐标，根据具体情况而定)
			//var realIndex $(this).index();
			//var y = Math.ceil() / 4;
			//var x = Math.ceil() % 4;
			
			clickTimes++;
			index = $(this).index();
			if(clickTimes%2===0){
				game.index2();
				game.success();
			}else{
				game.index();
			}
		});
	},

	//记录单数点击数据
	index:function(){
		game.initNum = game.original[index];
	},

	//记录双数点击数据
	index2:function(){
		game.initNum2 = game.original[index];
		if(game.initNum2 != game.initNum){
			setTimeout(function(num1,num2){
				$(".game-block").removeClass('on'+num1).removeClass('on'+num2);
				$(".game-block .on"+num1).removeClass('show');
				$(".game-block .on"+num2).removeClass('show');
			},500,game.initNum,game.initNum2);
			console.log("error,again");
		}else{
			game.success();
		}
	},

	//成功翻转
	success:function(){
		var showNum = 0;
		
		$(".game-block .show").each(function(){
			showNum++;
			if(showNum===16){
				//TODO 游戏结束，时间戳
				game.endTime = (new Date()).getTime();
				$(".game-block a").off("click");
				//TODO 保存游戏战绩
				
				clearInterval(game.addTime);
				$(".username").text("@"+game.wxName);
				game.minResult = $(".time-count .min").text();
				game.secResult = $(".time-count .sec").text();
				$(".min-s").text(game.minResult);
				$(".sec-s").text(game.secResult);
				$(".head").attr('src', game.wxImg);
				setTimeout(function(){
					$(".pop, .pop .pop-success,.success-share").show();
				},1000);
				//share2();
			}
		});
	},

	//计时
	timeCount:function(){
		game.timeSecond = 0;
		game.addTime = setInterval(function(){
			game.timeMinute = parseInt(game.timeSecond/60);
			$(".time-count .sec").text(game.timeSecond%60);
			$(".time-count .min").text(game.timeMinute);
			
			if(game.timeSecond%60 < 10){
				$(".time-count .sec").text("0"+game.timeSecond%60);
			}
			if(game.timeMinute <10){
				$(".time-count .min").text("0"+game.timeMinute);
			}
			game.timeSecond++;
		},1000);
	},

	//获取微信昵称，头像
	/*wxGet:function(){
        $.ajax({
            url: "http://weixin-api.vip.com/user/getUserInfo",
            type: 'get',
            dataType: 'jsonp',
            jsonp: 'jsonp',
            data: {
				type : 3,
				fs : 'vip'
            }
        })
        .done(game.wxGetback)
        .fail(function (xhr, status, err) {
            console.log('draw err:', err);
        });
	},*/

	/*wxGetback:function(res){
		var code = res.code - 0; 
		if(code === -33){
			location.href = res.data.redirectUrl + '?fs=' + res.data.fs + '&type=' + res.data.type + '&src=' + encodeURIComponent (location.href);
		}else{
			game.wxImg = res.data.headimgurl;
			game.wxName = res.data.nickname;
			share();
		}
	},*/

	// 获取URL参数
    getUrlParam: function (name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r !== null) {
            return (r[2]);
        }
        return ''; // 保证返回的数据格式是String
    },

    //重新开始游戏
    gameAgain:function(){
		$(".pop, .pop-success,.success-share").hide();
		$(".time-count .min, .time-count .sec").text('00');
		$(".timeBox").removeClass("on");
		var className = $('.game-block').attr("class");
		$(".game-block").removeClass(className).addClass("game-block");
		$(".game-block a").removeAttr("class").attr('class','aDis');
		game.init();
	},

	//分享成功返回
	backPop:function(){
		/*$(".pop, .pop-back").show();
		$(".pop .pop-back").siblings().hide();
		$(".backdrop, .wxPopover, .overlay").hide();*/
	}

};

var isFirst = true;
$(window).load(function(){
	$('#gclose').click(function(){
		var $pop = $(this).parents('.wrapper').hide().siblings('.wrapper').show().siblings('.pop');
		if(isFirst){
			$pop.addClass('fab1');
			isFirst = false;
		}
		if($(".pop").hasClass("fab1")){
			setTimeout(function(){
				$(".pop").removeClass("fab1").addClass("fab2");
			},2500);
			setTimeout(function(){
				$(".pop").removeClass("fab2").addClass("fab3");
			},4500);
			
			$('#iknow').click(function(){
				setTimeout(function(){
					$(".pop").removeClass("fab3").addClass("fab4");
					$(".pop-fab4 img").addClass("go");								
				},0);
				setTimeout(function(){
					$(".pop").removeClass("fab4").addClass("fab5");
					$(".pop-fab5 img").addClass("go");
				},1000);
				setTimeout(function(){
					$(".pop").removeClass("fab5").addClass("fab6");
					$(".pop-fab6 img").addClass("go");
				},2000);
				setTimeout(function(){
					$(".pop").removeClass("fab6").addClass("fab7");
					$(".pop-fab7 img").addClass("go");
				},3000);
				setTimeout(function(){
					$(".pop").removeClass("fab7");
				},4000);
			});
			
		}
	});
	
	$(".btn_publish").on("click",function(e){
		$(this).parents('.wrapper').hide().siblings('.wrapper').show();
	});
	$(".btn_join").on("click",function(e){
		$(".pop, .pop-activity").show();
	});
});

$(function(){
	game.init();
	// console.log(game.original);
	$(".startBtn").click(function(){
		//TODO 游戏开始，时间戳
		game.startTime = (new Date()).getTime();
		$(".timeBox").addClass("on");
		$(".game-block a").css("opacity","1");
		game.timeCount();
		setTimeout(function(){
			$(".game-block a").css("opacity","0").removeClass('aDis');
			game.clickEvent();
		},5000);
	});

	/*if(VIVA.platform=="weixin"){
		game.wxGet();
	}*/

	$(".gameBtn").click(function(event) {
		game.gameAgain();
	});


	//跳专题链接
//	var urlLink = "http://mst.vip.com/uploadfiles/exclusive_subject/te/v1/90498.php?wapid=mst_90498&_src=mst&page_msg=VIP_NH-all-all";
//	var mztLink = VIVA.addParams(urlLink);
//	$(".shopBtn img, .wxshop-btn").click(function(event) {
//		location.href = mztLink;
//	});

	//share2();
});

/*function share(){
	// 分享
    var shareUrl = window.location.href; //分享链接
    var titleRan = [game.wxName+'用了'+game.minResult+'分'+game.secResult+'秒就找到了小S，不服来战！',game.wxName+'以'+game.minResult+'分'+game.secResult+'秒在小S忠粉PK榜中领先，不服来战！'];
    var shareOpt = {
        dom: {
            shareBtn: '.shareBtn', //分享按钮
            backdrop: '.backdrop', //分享蒙层
            wxPopover: '.wxPopover', //微信分享蒙层
            wxPopClose: '.wxPopover', //微信分享蒙层关闭按钮
            wapPopover: '.wapPopover', //wap分享蒙层
            wapPopClose: '.cancelShareBtn' //wap分享弹层关闭按钮
        },
        weixin: {
            url: shareUrl, //分享链接
            title: titleRan[VIVA.randomInt(0,1)],
            img: game.wxImg, //分享图片
            text: '你离小S签名照只差这一步！', //若为数组 则随机1个元素作为分享文案
            isReport: true, //是否上报分享关系
            aid: 'fans', //上报分享关系的 活动id, 非空则表示上报数据 设置isReport=true
            hideMenus: false, //默认不隐藏右上角按钮 分享朋友圈
        },
        wap: {
            url: shareUrl, //分享链接
            title: '你离小S签名照还差一步！', //若为数组 则随机1个元素作为分享标题
            img: 'http://viva.vipstatic.com/uploadfiles/viva-act-static/fans/resources/images/wap.png', //分享图片
            auto: true, //自动添加分享链接到分享图标href，否则为data-href
            custom: '&summary=本宝宝仅花了'+game.minResult+'分'+game.secResult+'秒就找到了小S，小S忠粉们，不服来战！' //分享文案，前面需要有summary
        },
        app: {
            shareId: '', //分享组件ID
            actId: '' //原生分享ID
        },
        useTouchevent: false // 使用tap或者click
    };

    var share = new VivaShare(shareOpt);
}*/

/*function share2(){
	// 分享
    var shareUrl = window.location.href; //分享链接
    var titleRan = [game.wxName+'用了'+game.minResult+'分'+game.secResult+'秒就找到了小S，不服来战！',game.wxName+'以'+game.minResult+'分'+game.secResult+'秒在小S忠粉PK榜中领先，不服来战！'];
    var shareOpt = {
        dom: {
            shareBtn: '.shareBtn', //分享按钮
            backdrop: '.backdrop', //分享蒙层
            wxPopover: '.wxPopover', //微信分享蒙层
            wxPopClose: '.wxPopover', //微信分享蒙层关闭按钮
            wapPopover: '.wapPopover', //wap分享蒙层
            wapPopClose: '.cancelShareBtn' //wap分享弹层关闭按钮
        },
        weixin: {
            url: shareUrl, //分享链接
            title: titleRan[VIVA.randomInt(0,1)], //分享标题
            img: game.wxImg, //分享图片
            text: '你离小S签名照只差这一步！', //若为数组 则随机1个元素作为分享文案
            isReport: true, //是否上报分享关系
            aid: 'fans', //上报分享关系的 活动id, 非空则表示上报数据 设置isReport=true
            hideMenus: false, //默认不隐藏右上角按钮 分享朋友圈
            onsuccess:game.backPop
        },
        wap: {
            url: shareUrl, //分享链接
            title: '你离小S签名照还差一步！', //若为数组 则随机1个元素作为分享标题
            img: 'http://viva.vipstatic.com/uploadfiles/viva-act-static/fans/resources/images/wap.png', //分享图片
            auto: true, //自动添加分享链接到分享图标href，否则为data-href
            custom: '&summary=本宝宝仅花了'+game.minResult+'分'+game.secResult+'秒就找到了小S，小S忠粉们，不服来战！' //分享文案，前面需要有summary
        },
        app: {
            shareId: '', //分享组件ID
            actId: '' //原生分享ID
        },
        useTouchevent: false // 使用tap或者click
    };

    var share = new VivaShare(shareOpt);
}
	*/